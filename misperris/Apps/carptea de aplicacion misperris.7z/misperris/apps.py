from django.apps import AppConfig


class MisperrisConfig(AppConfig):
    name = 'misperris'
